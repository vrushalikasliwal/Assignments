﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace weekwiseSale
{
        public partial class Form1 : Form
    {
        string connStr = "Data Source=DELL\\MSSQLSERVER01;Initial Catalog=testassignment;Integrated Security=True";
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataSet ds = null;
        DataTable dt = null;
        String strQuery = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(connStr);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dgvData.DataSource = null;
            lbltot.Text = "";
            strQuery = "select DATEPART(week, a.DocDt)as dtweek,a.TrnType ,a.TrnCtrlNo,sum(DOCQTY) as totalQty,sum(DOCENTNETVALUE) as netSale from StkTrnHdr a inner join StkTrnDtls b on a.TRNTYPE =b.TRNTYPE and a.TRNCTRLNO=b.TRNCTRLNO group by DATEPART(week, a.DocDt),a.TrnType,a.TrnCtrlNo having a.TrnType  =2100";
            da = new SqlDataAdapter(strQuery, con);
            dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();
            dgvData.Refresh();
            dgvData.DataSource = dt;
            lbltot.Text = "Total No OF Rows:" + dt.Rows.Count;

        }
    }
}
