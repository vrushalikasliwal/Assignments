﻿namespace Assignment1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtHost = new TextBox();
            txtUsername = new TextBox();
            label2 = new Label();
            txtPassword = new TextBox();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            lstFiles = new ListBox();
            btnUpload = new Button();
            dgvViewData = new DataGridView();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvViewData).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(49, 28);
            label1.Name = "label1";
            label1.Size = new Size(32, 15);
            label1.TabIndex = 0;
            label1.Text = "Host";
            // 
            // txtHost
            // 
            txtHost.Location = new Point(124, 28);
            txtHost.Name = "txtHost";
            txtHost.Size = new Size(359, 23);
            txtHost.TabIndex = 1;
            txtHost.Text = "ftp://103.231.43.51";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(124, 73);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(359, 23);
            txtUsername.TabIndex = 3;
            txtUsername.Text = "Testuser";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(49, 73);
            label2.Name = "label2";
            label2.Size = new Size(65, 15);
            label2.TabIndex = 2;
            label2.Text = "User Name";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(124, 114);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(359, 23);
            txtPassword.TabIndex = 5;
            txtPassword.Text = "Test@123";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(49, 114);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 4;
            label3.Text = "Password";
            // 
            // button1
            // 
            button1.Location = new Point(124, 162);
            button1.Name = "button1";
            button1.Size = new Size(107, 31);
            button1.TabIndex = 6;
            button1.Text = "Connect";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(49, 412);
            button2.Name = "button2";
            button2.Size = new Size(140, 36);
            button2.TabIndex = 9;
            button2.Text = "Download";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(230, 405);
            button3.Name = "button3";
            button3.Size = new Size(140, 36);
            button3.TabIndex = 10;
            button3.Text = "Upload";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // lstFiles
            // 
            lstFiles.FormattingEnabled = true;
            lstFiles.ItemHeight = 15;
            lstFiles.Location = new Point(57, 211);
            lstFiles.Name = "lstFiles";
            lstFiles.Size = new Size(163, 154);
            lstFiles.TabIndex = 11;
            // 
            // btnUpload
            // 
            btnUpload.Location = new Point(256, 166);
            btnUpload.Name = "btnUpload";
            btnUpload.Size = new Size(75, 23);
            btnUpload.TabIndex = 12;
            btnUpload.Text = "Upload";
            btnUpload.UseVisualStyleBackColor = true;
            btnUpload.Click += btnUpload_Click;
            // 
            // dgvViewData
            // 
            dgvViewData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvViewData.Location = new Point(270, 215);
            dgvViewData.Name = "dgvViewData";
            dgvViewData.RowTemplate.Height = 25;
            dgvViewData.Size = new Size(490, 155);
            dgvViewData.TabIndex = 13;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(445, 416);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 14;
            label4.Text = "label4";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(902, 532);
            Controls.Add(label4);
            Controls.Add(dgvViewData);
            Controls.Add(btnUpload);
            Controls.Add(lstFiles);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtPassword);
            Controls.Add(label3);
            Controls.Add(txtUsername);
            Controls.Add(label2);
            Controls.Add(txtHost);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvViewData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtHost;
        private TextBox txtUsername;
        private Label label2;
        private TextBox txtPassword;
        private Label label3;
        private Button button1;
        private Button button2;
        private Button button3;
        private ListBox lstFiles;
        private Button btnUpload;
        private DataGridView dgvViewData;
        private Label label4;
    }
}