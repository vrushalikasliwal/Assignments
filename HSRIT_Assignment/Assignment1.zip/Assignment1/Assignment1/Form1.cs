using System.Data;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Data;

using System.Data.OleDb;
using IronXL;
using System.Reflection.Emit;
using System.Data.SqlClient;
//using System.Configuration;

namespace Assignment1
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string[] downloadFiles = GetFileList();

                for (int i = 0; i < downloadFiles.Length; i++)
                {
                    lstFiles.Items.Add(downloadFiles[i]);
                }
                lstFiles.Refresh();
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error (DOWNLOAD FILE ) :" + ex.Message + "\n");
            }
        }


        public string[] GetFileList()
        {
            string[] downloadFiles;
            StringBuilder result = new StringBuilder();
            WebResponse response = null;
            StreamReader reader = null;
            try
            {
                FtpWebRequest reqFTP;
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(txtHost.Text.Trim()));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(txtUsername.Text.Trim(), txtPassword.Text.Trim());
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
                reqFTP.Proxy = null;
                reqFTP.KeepAlive = false;
                reqFTP.UsePassive = false;
                response = reqFTP.GetResponse();
                reader = new StreamReader(response.GetResponseStream());
                string line = reader.ReadLine();
                while (line != null)
                {
                    string isExcelFile = "";
                    isExcelFile = line.LastIndexOf('.').ToString();
                    //if ((isExcelFile == ".xlsx") || (isExcelFile = ".csv")) 
                    //{
                    result.Append(line);
                    result.Append("#");
                    line = reader.ReadLine();
                    //} 
                    //else 
                    //{ 
                    //}

                }
                // to remove the trailing '\n'
                //  MessageBox.Show(line);
                result.Remove(result.ToString().LastIndexOf('#'), 1);
                return result.ToString().Split('#');
            }
            catch (Exception ex)
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
                downloadFiles = null;
                return downloadFiles;
            }
        }
        public void fillDGV(string flNm)
        {
            OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file
            if (file.ShowDialog() == DialogResult.OK) //if there is a file chosen by the user
            {
                string fileExt = Path.GetExtension(file.FileName); //get the file extension
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        DataTable dtExcel = ReadExcel(flNm); //read excel file
                        dgvViewData.Visible = true;
                        dgvViewData.DataSource = dtExcel;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (WebClient ftpClient = new WebClient())
                {
                    try
                    {

                        lstFiles.Refresh();
                        string downloadFilePath = txtHost.Text.Trim() + "/" + lstFiles.SelectedItem.ToString();
                        ftpClient.Credentials = new System.Net.NetworkCredential(txtUsername.Text, txtPassword.Text);
                        ftpClient.DownloadFile(downloadFilePath, "C:/Files/" + lstFiles.SelectedItem.ToString());
                        MessageBox.Show("File Downloaded");

                    }
                    catch (Exception ex)
                    {
����������������������� //Logger.LogInfo(ex);
����������������������� Console.WriteLine("Error (DOWNLOAD CSV FILE) :" + ex.Message + "\n");
                    }
                }
                OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file
                if (file.ShowDialog() == DialogResult.OK) //if there is a file chosen by the user
                {
                    string str;
                    str = "C:/Files/" + lstFiles.SelectedItem.ToString();
                    string fileExt = Path.GetExtension(str); //get the file extension
                    if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                    {
                        try
                        {
                            DataTable dtExcel = ReadExcel(str); //read excel file
                            dgvViewData.Visible = true;
                            dgvViewData.DataSource = dtExcel;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message.ToString());
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error (DOWNLOAD FILE ) :" + ex.Message + "\n");
            }
        }
        public string sConnectionString;

        private void btnUpload_Click(object sender, EventArgs e)
        {
            /* // ReadFile();
             OpenFileDialog op = new OpenFileDialog();
             op.Filter = "Excel 97 - 2003|*.xls|Excel 2007|*.xlsx";
             if (op.ShowDialog() == System.Windows.Forms.DialogResult.OK)
             {
                 if (File.Exists(op.FileName))
                 {
                     string[] Arr = null;
                     Arr = op.FileName.Split('.');
                     if (Arr.Length > 0)
                     {
                         if (Arr[Arr.Length - 1] == "xls")
                             sConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
                             op.FileName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1'";
                     }
                     else if (Arr[Arr.Length - 1] == "xlsx")
                     {
                         sConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + op.FileName + ";Extended Properties='Excel 12.0 Xml;HDR=YES';";
                     }
                 }


                 FillData();
             }*/
            OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file
            if (file.ShowDialog() == DialogResult.OK) //if there is a file chosen by the user
            {
                string fileExt = Path.GetExtension(file.FileName); //get the file extension
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        DataTable dtExcel = ReadExcel(file.FileName); //read excel file
                        dgvViewData.Visible = true;
                        dgvViewData.DataSource = dtExcel;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error
                }
            }
        }
        private DataTable ReadExcel(string fileName)
        {
            WorkBook workbook = WorkBook.Load(fileName);
            //// Work with a single WorkSheet.
            ////you can pass static sheet name like Sheet1 to get that sheet
            ////WorkSheet sheet = workbook.GetWorkSheet("Sheet1");
            //You can also use workbook.DefaultWorkSheet to get default in case you want to get first sheet only
            WorkSheet sheet = workbook.DefaultWorkSheet;
            //Convert the worksheet to System.Data.DataTable
            //Boolean parameter sets the first row as column names of your table.
            return sheet.ToDataTable(true);
        }
        /*private void FillData()
        {
            if (sConnectionString.Length > 0)
            {
                OleDbConnection cn = new OleDbConnection(sConnectionString);
                {
                    cn.Open();
                    DataTable dt = new DataTable();
                    OleDbDataAdapter Adpt = new OleDbDataAdapter("select * from [sheet1$]", cn);
                    Adpt.Fill(dt);
                    dgvViewData.DataSource = dt;
                }

         catch (Exception ex)
         {
                }
            }
        }*/

        private void ReadFile()
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            string connStr = "Data Source=DELL\\MSSQLSERVER01;Initial Catalog=Testdb;Integrated Security=True";

            SqlCommand com;
            foreach (DataGridViewRow g1 in dgvViewData.Rows)
            {
                SqlConnection con = new SqlConnection(connStr);
                con.Open();
                string cmdStr = "insert into SalesDtlSample([Store],[BiilPrefix],[BiilNo],[BillDate],[EntSriNo],[StockNo],[Qty],[Rate],[BaseValue],[Discount],[ValAftDisc],[Tax],[DocEntNetVal],[FileName],[currDateTime]) values ('" + g1.Cells[0].Value + "','" + g1.Cells[1].Value + "','" + g1.Cells[2].Value + "','" + Convert.ToDateTime(g1.Cells[3].Value.ToString()).ToString("yyyy-MM-dd HH:mm:ss") + "','" + g1.Cells[4].Value + "','" + g1.Cells[5].Value + "','" + g1.Cells[6].Value + "','" + g1.Cells[7].Value + "','" + g1.Cells[8].Value + "','" + g1.Cells[9].Value + "','" + g1.Cells[10].Value + "','" + g1.Cells[11].Value + "','" + g1.Cells[12].Value + "','" + lstFiles.SelectedItem.ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                com = new SqlCommand(cmdStr, con);

                com.ExecuteNonQuery();
                con.Close();
            }
            label4.Text = "Records inserted successfully";
        }
    }
}