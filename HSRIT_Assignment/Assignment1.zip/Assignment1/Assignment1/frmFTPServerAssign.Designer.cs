﻿namespace Assignment1
{
    partial class frmFTPServerAssign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPassword = new TextBox();
            label3 = new Label();
            txtUsername = new TextBox();
            label2 = new Label();
            txtHost = new TextBox();
            label1 = new Label();
            btnConnect = new Button();
            lblConnect = new Label();
            lstFiles = new ListBox();
            dgvViewData = new DataGridView();
            button2 = new Button();
            button3 = new Button();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvViewData).BeginInit();
            SuspendLayout();
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(212, 109);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(183, 23);
            txtPassword.TabIndex = 11;
            txtPassword.Text = "Test@123";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(147, 112);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 10;
            label3.Text = "Password:";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(212, 68);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(183, 23);
            txtUsername.TabIndex = 9;
            txtUsername.Text = "Testuser";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(139, 71);
            label2.Name = "label2";
            label2.Size = new Size(68, 15);
            label2.TabIndex = 8;
            label2.Text = "User Name:";
            // 
            // txtHost
            // 
            txtHost.Location = new Point(212, 23);
            txtHost.Name = "txtHost";
            txtHost.Size = new Size(183, 23);
            txtHost.TabIndex = 7;
            txtHost.Text = "ftp://103.231.43.51";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(172, 26);
            label1.Name = "label1";
            label1.Size = new Size(35, 15);
            label1.TabIndex = 6;
            label1.Text = "Host:";
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(139, 162);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(187, 26);
            btnConnect.TabIndex = 12;
            btnConnect.Text = "Connect And Show List OF Files";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // lblConnect
            // 
            lblConnect.AutoSize = true;
            lblConnect.Location = new Point(332, 168);
            lblConnect.Name = "lblConnect";
            lblConnect.Size = new Size(63, 15);
            lblConnect.TabIndex = 13;
            lblConnect.Text = "IsConnect:";
            // 
            // lstFiles
            // 
            lstFiles.FormattingEnabled = true;
            lstFiles.ItemHeight = 15;
            lstFiles.Location = new Point(444, 23);
            lstFiles.Name = "lstFiles";
            lstFiles.Size = new Size(190, 109);
            lstFiles.TabIndex = 14;
            lstFiles.SelectedIndexChanged += lstFiles_SelectedIndexChanged;
            // 
            // dgvViewData
            // 
            dgvViewData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvViewData.Location = new Point(22, 194);
            dgvViewData.Name = "dgvViewData";
            dgvViewData.RowTemplate.Height = 25;
            dgvViewData.Size = new Size(744, 169);
            dgvViewData.TabIndex = 15;
            // 
            // button2
            // 
            button2.Location = new Point(488, 155);
            button2.Name = "button2";
            button2.Size = new Size(209, 27);
            button2.TabIndex = 16;
            button2.Text = "Download All Files";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(316, 388);
            button3.Name = "button3";
            button3.Size = new Size(140, 36);
            button3.TabIndex = 17;
            button3.Text = "Upload in Database";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(553, 399);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 18;
            label4.Text = "label4";
            // 
            // frmFTPServerAssign
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(dgvViewData);
            Controls.Add(lstFiles);
            Controls.Add(lblConnect);
            Controls.Add(btnConnect);
            Controls.Add(txtPassword);
            Controls.Add(label3);
            Controls.Add(txtUsername);
            Controls.Add(label2);
            Controls.Add(txtHost);
            Controls.Add(label1);
            Name = "frmFTPServerAssign";
            Text = "frmFTPServerAssign";
            ((System.ComponentModel.ISupportInitialize)dgvViewData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPassword;
        private Label label3;
        private TextBox txtUsername;
        private Label label2;
        private TextBox txtHost;
        private Label label1;
        private Button btnConnect;
        private Label lblConnect;
        private ListBox lstFiles;
        private DataGridView dgvViewData;
        private Button button2;
        private Button button3;
        private Label label4;
    }
}