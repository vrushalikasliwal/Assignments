﻿//using System;
//using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using IronXL;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Reflection;

namespace Assignment1
{
    public partial class frmFTPServerAssign : Form
    {
        public frmFTPServerAssign()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                string[] downloadFiles = GetFileList();
                lstFiles.Items.Clear();
                for (int i = 0; i < downloadFiles.Length; i++)
                {
                    lstFiles.Items.Add(downloadFiles[i]);
                }
                lstFiles.Refresh();
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error (DOWNLOAD FILE ) :" + ex.Message + "\n");
            }
        }
        public string[] GetFileList()
        {
            //string[] downloadFiles;
            StringBuilder result = new StringBuilder();
            WebResponse response = null;
            StreamReader reader = null;
            lblConnect.Text = "";
            try
            {
                FtpWebRequest reqFTP;
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(txtHost.Text.Trim()));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(txtUsername.Text.Trim(), txtPassword.Text.Trim());
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
                reqFTP.Proxy = null;
                reqFTP.KeepAlive = false;
                reqFTP.UsePassive = false;
                response = reqFTP.GetResponse();
                lblConnect.Text = "FTP Server Connect";
                reader = new StreamReader(response.GetResponseStream());
                string line = reader.ReadLine();
                while (line != null)
                {
                    if (line.Contains(".xlsx") || line.Contains(".csv"))
                    {
                        result.Append(line);
                        result.Append("#");
                        line = reader.ReadLine();
                    }

                }
                // to remove the trailing '\n'
                result.Remove(result.ToString().LastIndexOf('#'), 1);
                return result.ToString().Split('#');
            }
            catch (Exception ex)
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
                lblConnect.Text = "";
                result = null;
                return null;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (WebClient ftpClient = new WebClient())
                {
                    try
                    {
                        //MessageBox.Show(Application.StartupPath);

                        lstFiles.Refresh();
                        int no = lstFiles.Items.Count;
                        for (int i = 0; no > 0; no--)
                        {
                            string downloadFilePath = txtHost.Text.Trim() + "/" + lstFiles.Items[i].ToString();
                            string toPAth = Application.StartupPath + "Files\\" + lstFiles.Items[i].ToString();
                           toPAth= toPAth.Replace("'\'","/");
                            ftpClient.Credentials = new System.Net.NetworkCredential(txtUsername.Text, txtPassword.Text);
                            ftpClient.DownloadFile(downloadFilePath, toPAth);
                            i++;
                        }
                        MessageBox.Show("File All Files Downloaded");

                    }
                    catch (Exception ex)
                    {
                        //Logger.LogInfo(ex);
                        Console.WriteLine("Error (DOWNLOAD CSV FILE) :" + ex.Message + "\n");
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error (DOWNLOAD FILE ) :" + ex.Message + "\n");
            }
        }

        private void lstFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            //OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file
            //if (file.ShowDialog() == DialogResult.OK) //if there is a file chosen by the user
            //{
            string str;
            str = Application.StartupPath + "Files\\" + lstFiles.SelectedItem.ToString();
            str = str.Replace("'\'", "/");
            //str = "C:/Files/" + lstFiles.SelectedItem.ToString();
            string fileExt = Path.GetExtension(str); //get the file extension
            if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
            {
                try
                {
                    DataTable dtExcel = ReadExcel(str); //read excel file
                    dgvViewData.Visible = true;
                    dgvViewData.DataSource = dtExcel;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error
            }
            //}
        }
        private DataTable ReadExcel(string fileName)
        {
            WorkBook workbook = WorkBook.Load(fileName);
            //// Work with a single WorkSheet.
            ////you can pass static sheet name like Sheet1 to get that sheet
            ////WorkSheet sheet = workbook.GetWorkSheet("Sheet1");
            //You can also use workbook.DefaultWorkSheet to get default in case you want to get first sheet only
            WorkSheet sheet = workbook.DefaultWorkSheet;
            //Convert the worksheet to System.Data.DataTable
            //Boolean parameter sets the first row as column names of your table.
            return sheet.ToDataTable(true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connStr = "Data Source=DELL\\MSSQLSERVER01;Initial Catalog=Testdb;Integrated Security=True";
            SqlConnection con = new SqlConnection(connStr);

            string cmdStr = "";
            SqlCommand com;
            if (lstFiles.SelectedItem.ToString() == "SalesDetails Sample.xlsx")
            {
                con.Open();
                cmdStr = "DELETE FROM [dbo].[SalesDtlSample]";
                com = new SqlCommand(cmdStr, con);
                com.ExecuteNonQuery();
                con.Close();

                foreach (DataGridViewRow g1 in dgvViewData.Rows)
                {
                    if (g1.Index != dgvViewData.Rows.Count-1)
                    {
                        con.Open();

                        cmdStr = "insert into SalesDtlSample([Store],[BiilPrefix],[BiilNo],[BillDate],[EntSriNo],[StockNo],[Qty],[Rate],[BaseValue],[Discount],[ValAftDisc],[Tax],[DocEntNetVal],[FileName],[currDateTime]) values ('" + g1.Cells[0].Value + "','" + g1.Cells[1].Value + "','" + g1.Cells[2].Value + "','" + Convert.ToDateTime(g1.Cells[3].Value.ToString()).ToString("yyyy-MM-dd HH:mm:ss") + "','" + g1.Cells[4].Value + "','" + g1.Cells[5].Value + "','" + g1.Cells[6].Value + "','" + g1.Cells[7].Value + "','" + g1.Cells[8].Value + "','" + g1.Cells[9].Value + "','" + g1.Cells[10].Value + "','" + g1.Cells[11].Value + "','" + g1.Cells[12].Value + "','" + lstFiles.SelectedItem.ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                        com = new SqlCommand(cmdStr, con);

                        com.ExecuteNonQuery();
                        con.Close();

                    }
                    con.Close();
                }
            }
            if (lstFiles.SelectedItem.ToString() == "StoreLocation Sample.xlsx")
            {
                con.Open();
                cmdStr = "DELETE FROM [dbo].[tblLocation]";
                com = new SqlCommand(cmdStr, con);
                com.ExecuteNonQuery();
                con.Close();

                foreach (DataGridViewRow g1 in dgvViewData.Rows)
                {
                    if (g1.Index != dgvViewData.Rows.Count-1)
                    {
                        con.Open();
                        
                        cmdStr = "INSERT INTO [dbo].[tblLocation]([Country],[Zone],[State],[City],[Store],[fileNm],[tDAte]) VALUES('" + g1.Cells[0].Value.ToString() + "','" + g1.Cells[1].Value.ToString() + "','" + g1.Cells[2].Value.ToString() + "','" + g1.Cells[3].Value.ToString() + "','"+ g1.Cells[4].Value.ToString() + "','" +lstFiles.SelectedItem.ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                        com = new SqlCommand(cmdStr, con);
                                                com.ExecuteNonQuery();
                        con.Close();

                    }
                    con.Close();
                }
            }
            label4.Text = "Records inserted successfully";
        }
    }
}
