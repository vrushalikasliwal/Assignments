using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        string connStr = "Data Source=DELL\\MSSQLSERVER01;Initial Catalog=Testdb;Integrated Security=True";
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataSet ds = null;
        DataTable dt = null;
        String strQuery = "";
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(connStr);
            strQuery = "select distinct state from tblLocation";
            da = new SqlDataAdapter(strQuery, con);
            dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();
            cmbState.DataSource = dt;
            cmbState.DisplayMember = "State";
            cmbState.ValueMember = "State";

            strQuery = "select distinct city from tblLocation";
            da = new SqlDataAdapter(strQuery, con);
            dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();
            cmbCity.DataSource = dt;
            cmbCity.DisplayMember = "city";
            cmbCity.ValueMember = "city";

            strQuery = "select distinct store from tblLocation";
            da = new SqlDataAdapter(strQuery, con);
            dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();
            cmbStore.DataSource = dt;
            cmbStore.DisplayMember = "Store";
            cmbStore.ValueMember = "Store";
            lblTotRow.Text = "";

            //fromDt.CustomFormat = "dd/MM/yyyy";
            //toDt.Format = DateTimePickerFormat.Custom;
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            lblTotRow.Text = "";
            strQuery = "SELECT [BillDate],biilno,[EntSriNo],sum([Qty])Qty ,rate,BaseValue,Discount,ValAftDisc,Tax,DocEntNetVal FROM[dbo].[SalesDtlSample] a inner join tblLocation b on a.Store = b.Store Where [State] ='" + cmbState.SelectedValue.ToString() + "' And City = '" + cmbCity.SelectedValue.ToString() + "' And b.[Store]= '" + cmbStore.SelectedValue.ToString() + "' And [BillDate] between '" + fromDt.Value.ToString("yyyy/MM/dd") + "' and '" + toDt.Value.ToString("yyyy/MM/dd") + "' Group by [BillDate],biilno,[EntSriNo],rate,BaseValue,Discount,ValAftDisc,Tax,DocEntNetVal order by [BillDate],biilno,[EntSriNo]";
            //strQuery = "SELECT [BillDate],b.[Store],[State],City,[EntSriNo],sum([Qty]) Qty FROM [dbo].[SalesDtlSample] a inner join tblLocation b on a.Store=b.Store Where [BillDate] between '" + fromDt.Value.ToString("yyyy/MM/dd") + "' and '" + toDt.Value.ToString("yyyy/MM/dd") + "' And b.[Store]='" + cmbStore.SelectedValue.ToString() + "' Group by [BillDate],b.[Store],[State],City,[EntSriNo]";
            da = new SqlDataAdapter(strQuery, con);
            dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();
            dgvData.Refresh();
            dgvData.DataSource = null;
            dgvData.DataSource = dt;
            lblTotRow.Text = "Total No OF Rows:" + dt.Rows.Count;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblTotRow.Text = "";
            strQuery = "SELECT[State],City,b.[Store],[BillDate],biilno,[EntSriNo],sum([Qty])Qty ,rate,BaseValue,Discount,ValAftDisc,Tax,DocEntNetVal FROM[dbo].[SalesDtlSample] a inner join tblLocation b on a.Store = b.Store Group by[State], City, b.[Store],[BillDate],[EntSriNo],biilno,rate,BaseValue,Discount,ValAftDisc,Tax,DocEntNetVal order by b.[Store],[State],City,[BillDate],biilno,[EntSriNo]";
            da = new SqlDataAdapter(strQuery, con);
            dt = new DataTable();
            con.Open();
            da.Fill(dt);
            con.Close();
            dgvData.Refresh();
            dgvData.DataSource = null;
            dgvData.DataSource = dt;
            lblTotRow.Text = "Total No OF Rows:" + dt.Rows.Count;

        }
    }
}