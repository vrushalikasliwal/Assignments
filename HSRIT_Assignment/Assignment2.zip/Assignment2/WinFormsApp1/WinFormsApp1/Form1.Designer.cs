﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            fromDt = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            toDt = new DateTimePicker();
            label3 = new Label();
            cmbStore = new ComboBox();
            dgvData = new DataGridView();
            btnShow = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvData).BeginInit();
            SuspendLayout();
            // 
            // fromDt
            // 
            fromDt.CustomFormat = "dd/MM/yyyy";
            fromDt.Format = DateTimePickerFormat.Custom;
            fromDt.Location = new Point(106, 23);
            fromDt.Name = "fromDt";
            fromDt.Size = new Size(114, 23);
            fromDt.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 26);
            label1.Name = "label1";
            label1.Size = new Size(65, 15);
            label1.TabIndex = 1;
            label1.Text = "From Date:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(272, 27);
            label2.Name = "label2";
            label2.Size = new Size(49, 15);
            label2.TabIndex = 3;
            label2.Text = "To Date:";
            // 
            // toDt
            // 
            toDt.CustomFormat = "dd/MM/yyyy";
            toDt.Format = DateTimePickerFormat.Custom;
            toDt.Location = new Point(327, 23);
            toDt.Name = "toDt";
            toDt.Size = new Size(114, 23);
            toDt.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(514, 23);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 4;
            label3.Text = "Store:";
            // 
            // cmbStore
            // 
            cmbStore.FormattingEnabled = true;
            cmbStore.Location = new Point(557, 23);
            cmbStore.Name = "cmbStore";
            cmbStore.Size = new Size(159, 23);
            cmbStore.TabIndex = 5;
            // 
            // dgvData
            // 
            dgvData.AllowUserToAddRows = false;
            dgvData.AllowUserToDeleteRows = false;
            dgvData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvData.Location = new Point(50, 143);
            dgvData.Name = "dgvData";
            dgvData.ReadOnly = true;
            dgvData.Size = new Size(666, 234);
            dgvData.TabIndex = 6;
            // 
            // btnShow
            // 
            btnShow.Location = new Point(327, 77);
            btnShow.Name = "btnShow";
            btnShow.Size = new Size(75, 23);
            btnShow.TabIndex = 7;
            btnShow.Text = "Show";
            btnShow.UseVisualStyleBackColor = true;
            btnShow.Click += btnShow_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnShow);
            Controls.Add(dgvData);
            Controls.Add(cmbStore);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(toDt);
            Controls.Add(label1);
            Controls.Add(fromDt);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker fromDt;
        private Label label1;
        private Label label2;
        private DateTimePicker toDt;
        private Label label3;
        private ComboBox cmbStore;
        private Button btnShow;
        private DataGridView dgvData;
    }
}