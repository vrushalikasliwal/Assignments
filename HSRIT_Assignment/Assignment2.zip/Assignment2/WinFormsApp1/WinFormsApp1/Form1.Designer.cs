﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            fromDt = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            toDt = new DateTimePicker();
            label3 = new Label();
            cmbStore = new ComboBox();
            dgvData = new DataGridView();
            btnShow = new Button();
            cmbState = new ComboBox();
            label4 = new Label();
            cmbCity = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            button1 = new Button();
            lblTotRow = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvData).BeginInit();
            SuspendLayout();
            // 
            // fromDt
            // 
            fromDt.CustomFormat = "dd/MM/yyyy";
            fromDt.Format = DateTimePickerFormat.Custom;
            fromDt.Location = new Point(218, 84);
            fromDt.Name = "fromDt";
            fromDt.Size = new Size(114, 23);
            fromDt.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(147, 87);
            label1.Name = "label1";
            label1.Size = new Size(65, 15);
            label1.TabIndex = 1;
            label1.Text = "From Date:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(384, 88);
            label2.Name = "label2";
            label2.Size = new Size(49, 15);
            label2.TabIndex = 3;
            label2.Text = "To Date:";
            // 
            // toDt
            // 
            toDt.CustomFormat = "dd/MM/yyyy";
            toDt.Format = DateTimePickerFormat.Custom;
            toDt.Location = new Point(439, 84);
            toDt.Name = "toDt";
            toDt.Size = new Size(114, 23);
            toDt.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(495, 126);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 4;
            label3.Text = "Store:";
            // 
            // cmbStore
            // 
            cmbStore.FormattingEnabled = true;
            cmbStore.Location = new Point(552, 123);
            cmbStore.Name = "cmbStore";
            cmbStore.Size = new Size(159, 23);
            cmbStore.TabIndex = 5;
            // 
            // dgvData
            // 
            dgvData.AllowUserToAddRows = false;
            dgvData.AllowUserToDeleteRows = false;
            dgvData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvData.Location = new Point(12, 225);
            dgvData.MultiSelect = false;
            dgvData.Name = "dgvData";
            dgvData.ReadOnly = true;
            dgvData.Size = new Size(927, 305);
            dgvData.TabIndex = 6;
            // 
            // btnShow
            // 
            btnShow.Location = new Point(328, 161);
            btnShow.Name = "btnShow";
            btnShow.Size = new Size(75, 23);
            btnShow.TabIndex = 7;
            btnShow.Text = "Show";
            btnShow.UseVisualStyleBackColor = true;
            btnShow.Click += btnShow_Click;
            // 
            // cmbState
            // 
            cmbState.FormattingEnabled = true;
            cmbState.Location = new Point(56, 123);
            cmbState.Name = "cmbState";
            cmbState.Size = new Size(159, 23);
            cmbState.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 126);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 8;
            label4.Text = "State:";
            // 
            // cmbCity
            // 
            cmbCity.FormattingEnabled = true;
            cmbCity.Location = new Point(310, 123);
            cmbCity.Name = "cmbCity";
            cmbCity.Size = new Size(159, 23);
            cmbCity.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(267, 126);
            label5.Name = "label5";
            label5.Size = new Size(31, 15);
            label5.TabIndex = 10;
            label5.Text = "City:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(273, 18);
            label6.Name = "label6";
            label6.Size = new Size(217, 30);
            label6.TabIndex = 12;
            label6.Text = "Bill Summery Report";
            // 
            // button1
            // 
            button1.Location = new Point(439, 161);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 13;
            button1.Text = "Show All";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblTotRow
            // 
            lblTotRow.AutoSize = true;
            lblTotRow.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lblTotRow.Location = new Point(405, 207);
            lblTotRow.Name = "lblTotRow";
            lblTotRow.Size = new Size(101, 17);
            lblTotRow.TabIndex = 14;
            lblTotRow.Text = "Total No Rows:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(951, 542);
            Controls.Add(lblTotRow);
            Controls.Add(button1);
            Controls.Add(label6);
            Controls.Add(cmbCity);
            Controls.Add(label5);
            Controls.Add(cmbState);
            Controls.Add(label4);
            Controls.Add(btnShow);
            Controls.Add(dgvData);
            Controls.Add(cmbStore);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(toDt);
            Controls.Add(label1);
            Controls.Add(fromDt);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker fromDt;
        private Label label1;
        private Label label2;
        private DateTimePicker toDt;
        private Label label3;
        private ComboBox cmbStore;
        private Button btnShow;
        private DataGridView dgvData;
        private ComboBox cmbState;
        private Label label4;
        private ComboBox cmbCity;
        private Label label5;
        private Label label6;
        private Button button1;
        private Label lblTotRow;
    }
}